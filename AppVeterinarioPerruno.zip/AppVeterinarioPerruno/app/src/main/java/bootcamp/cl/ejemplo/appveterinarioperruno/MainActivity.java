package bootcamp.cl.ejemplo.appveterinarioperruno;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

// A una pantalla o vista del programa se le conoce como Activity
//Por cada activity siempre hay un archivo layout
public class MainActivity extends AppCompatActivity {

    /*
    Declaración del objetos de la clase View
    Sirven para comunicarse con la interfaz de android
     */
    TextView tituloAplicacion;
    EditText campoEdadPerro;
    Button botonCalcularEdad;
    Button irActividad;
    TextView respuestaEdad;

    /*
    Variables para lógica
     */
    String respuestaPantalla;
    String edadCampoRecibido = "";
    int campoEdadRecibidoNumero;
    int edadCanina;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Log.d("MainActivity","La activity se ha creado");

        /*
        Traigo la vista a la actividad
         */
        tituloAplicacion = findViewById(R.id.tituloApp);
        tituloAplicacion.setGravity(Gravity.CENTER);
        campoEdadPerro = findViewById(R.id.campoEdad);
        botonCalcularEdad = findViewById(R.id.bontonCalcular);
        respuestaEdad = findViewById(R.id.respuestaEdad);
        irActividad = findViewById(R.id.bontonNavegar);

        /*
        Funcionalidad que calcula la edad del perro
         */

        botonCalcularEdad.setOnClickListener((View view) -> {

            edadCampoRecibido=campoEdadPerro.getText().toString();

            if (!edadCampoRecibido.isEmpty()) {
                campoEdadRecibidoNumero= Integer.parseInt(edadCampoRecibido);
                edadCanina = calcularEdadPerruna(campoEdadRecibidoNumero);
                respuestaPantalla = getString(R.string.resultado_edad,edadCanina);
                //String respuestaPantalla = "Tu Edad canina es de " + edadPantalla + " años perrunos";
                respuestaEdad.setText(respuestaPantalla);
            } else {
                Toast.makeText(this, getString(R.string.mensaje_validacion), Toast.LENGTH_SHORT).show();
            }
        });

        /*
        Funcionalidad de la app que lleva a la ficha del perro cuando presiona el Botón
         */
        irActividad.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                abrirActividadFichaAnimal();
            }
        });

    }

    /*
    fUNCIÓN que calcula la edad de un perro a la de un humano, basándose en la teoría que
    la edad de un perro equivale a 7 veces la de un humano.
    Recibe como parametro la edad del perro ingresada por teclado.
     */
    public int calcularEdadPerruna(int campoEdad){
        int edadCaninaLocal=0;
        edadCaninaLocal = campoEdad*7;
        return edadCaninaLocal;
    }


    private void abrirActividadFichaAnimal(){

        if (!edadCampoRecibido.isEmpty()) {

            Intent intentoFicha = new Intent(this, FichaPerroActivity.class);
            startActivity(intentoFicha);

           // Toast.makeText(this, getString(R.string.mensaje_exito), Toast.LENGTH_SHORT).show();

        } else {
            Toast.makeText(this, getString(R.string.mensaje_validacion), Toast.LENGTH_SHORT).show();
        }
        // intent.putExtra(DetailActivity.SUPERHERO_KEY,nuevoSuperheroe);
        // startActivity(intent);

    }

}